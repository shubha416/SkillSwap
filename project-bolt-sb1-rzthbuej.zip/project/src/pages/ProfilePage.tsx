import React from 'react';
import { useParams } from 'react-router-dom';
import ProfileHeader from '../components/profile/ProfileHeader';
import SkillList from '../components/profile/SkillList';
import ReviewList from '../components/reviews/ReviewList';
import { useAuth } from '../context/AuthContext';
import { mockUsers, mockReviews } from '../data/mockData';

const ProfilePage: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const { currentUser } = useAuth();
  
  // For demo purposes, find the user from mock data
  const user = mockUsers.find(u => u.id === userId) || currentUser;
  
  if (!user) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">User not found</h2>
        <p className="text-gray-600">The user you're looking for doesn't exist or has been removed.</p>
      </div>
    );
  }
  
  const isCurrentUser = currentUser?.id === user.id;
  
  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <ProfileHeader user={user} isCurrentUser={isCurrentUser} />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">About</h2>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <p className="text-gray-700">{user.bio}</p>
            </div>
          </div>
          
          <ReviewList 
            reviews={mockReviews} 
            reviewCount={user.reviewCount} 
            averageRating={user.rating}
          />
        </div>
        
        <div className="space-y-8">
          <SkillList
            title="Skills I Can Teach"
            skills={user.skills}
            emptyMessage={isCurrentUser 
              ? "You haven't added any skills yet. Add skills to start teaching others." 
              : "This user hasn't added any skills yet."}
          />
          
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Skills I Want to Learn</h2>
            
            {user.interests.length > 0 ? (
              <ul className="space-y-2">
                {user.interests.map((interest, index) => (
                  <li key={index} className="flex items-center">
                    <span className="w-2 h-2 rounded-full bg-secondary-500 mr-2"></span>
                    <span className="text-gray-700">{interest}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500">
                {isCurrentUser 
                  ? "You haven't added any interests yet. Add interests to find people who can teach you." 
                  : "This user hasn't added any interests yet."}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;