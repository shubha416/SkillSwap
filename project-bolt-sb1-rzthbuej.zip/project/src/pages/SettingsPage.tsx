import React, { useState } from 'react';
import { User, Settings, Shield, Bell, Lock } from 'lucide-react';
import { Card, CardHeader, CardBody } from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { useAuth } from '../context/AuthContext';

const SettingsPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  
  if (!currentUser) return null;
  
  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfileSettings user={currentUser} />;
      case 'skills':
        return <SkillsSettings user={currentUser} />;
      case 'account':
        return <AccountSettings />;
      case 'notifications':
        return <NotificationSettings />;
      default:
        return <ProfileSettings user={currentUser} />;
    }
  };
  
  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Settings</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="md:col-span-1">
          <Card>
            <CardBody className="p-0">
              <nav className="space-y-1">
                <SettingsNavItem 
                  icon={User} 
                  title="Profile" 
                  active={activeTab === 'profile'} 
                  onClick={() => setActiveTab('profile')} 
                />
                <SettingsNavItem 
                  icon={Settings} 
                  title="Skills & Interests" 
                  active={activeTab === 'skills'} 
                  onClick={() => setActiveTab('skills')} 
                />
                <SettingsNavItem 
                  icon={Lock} 
                  title="Account" 
                  active={activeTab === 'account'} 
                  onClick={() => setActiveTab('account')} 
                />
                <SettingsNavItem 
                  icon={Bell} 
                  title="Notifications" 
                  active={activeTab === 'notifications'} 
                  onClick={() => setActiveTab('notifications')} 
                />
              </nav>
            </CardBody>
          </Card>
        </div>
        
        <div className="md:col-span-3">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

interface SettingsNavItemProps {
  icon: React.ElementType;
  title: string;
  active: boolean;
  onClick: () => void;
}

const SettingsNavItem: React.FC<SettingsNavItemProps> = ({ 
  icon: Icon, 
  title, 
  active, 
  onClick 
}) => {
  return (
    <button
      className={`flex items-center w-full px-4 py-3 text-left ${
        active 
          ? 'bg-primary-50 text-primary-700 border-l-4 border-primary-500' 
          : 'text-gray-700 hover:bg-gray-50'
      }`}
      onClick={onClick}
    >
      <Icon className={`h-5 w-5 ${active ? 'text-primary-500' : 'text-gray-500'} mr-3`} />
      <span className="text-sm font-medium">{title}</span>
    </button>
  );
};

interface ProfileSettingsProps {
  user: any;
}

const ProfileSettings: React.FC<ProfileSettingsProps> = ({ user }) => {
  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-900">Profile Information</h2>
      </CardHeader>
      
      <CardBody className="space-y-6">
        <div className="flex items-center">
          <div className="h-20 w-20 rounded-full bg-primary-100 flex items-center justify-center overflow-hidden">
            {user.avatar ? (
              <img 
                src={user.avatar} 
                alt={user.name}
                className="h-full w-full object-cover"
              />
            ) : (
              <span className="text-2xl font-bold text-primary-500">
                {user.name.charAt(0).toUpperCase()}
              </span>
            )}
          </div>
          
          <div className="ml-6">
            <Button variant="outline" size="sm">
              Change Photo
            </Button>
            <p className="mt-2 text-xs text-gray-500">
              JPG, GIF or PNG. 2MB max.
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input 
            label="Full Name" 
            defaultValue={user.name} 
          />
          
          <Input 
            label="Email Address" 
            type="email" 
            defaultValue="alex.johnson@example.com" 
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Bio
          </label>
          <textarea 
            rows={4}
            defaultValue={user.bio}
            className="block w-full rounded-md shadow-sm border-gray-300 focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50"
          />
          <p className="mt-1 text-xs text-gray-500">
            Brief description for your profile. URLs are hyperlinked.
          </p>
        </div>
        
        <Input 
          label="Location" 
          defaultValue={user.location} 
        />
        
        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
          <div className="flex items-center">
            <Shield className="h-5 w-5 text-primary-500 mr-2" />
            <span className="text-sm font-medium text-gray-700">
              {user.isVerified ? 'Your profile is verified' : 'Verify your profile'}
            </span>
          </div>
          
          {!user.isVerified && (
            <Button variant="outline" size="sm">
              Get Verified
            </Button>
          )}
        </div>
        
        <div className="pt-4 flex justify-end">
          <Button variant="primary">
            Save Changes
          </Button>
        </div>
      </CardBody>
    </Card>
  );
};

const SkillsSettings: React.FC<ProfileSettingsProps> = ({ user }) => {
  return (
    <div className="space-y-8">
      <Card>
        <CardHeader className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-900">Skills I Can Teach</h2>
          <Button variant="outline" size="sm">
            Add New Skill
          </Button>
        </CardHeader>
        
        <CardBody className="divide-y divide-gray-200">
          {user.skills.map((skill: any) => (
            <div key={skill.id} className="py-4 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-medium text-gray-900">{skill.name}</h3>
                <p className="text-xs text-gray-500">{skill.category} • {skill.proficiency}</p>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm">Edit</Button>
                <Button variant="danger" size="sm">Remove</Button>
              </div>
            </div>
          ))}
        </CardBody>
      </Card>
      
      <Card>
        <CardHeader className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-900">Skills I Want to Learn</h2>
          <Button variant="outline" size="sm">
            Add New Interest
          </Button>
        </CardHeader>
        
        <CardBody className="divide-y divide-gray-200">
          {user.interests.map((interest: string, index: number) => (
            <div key={index} className="py-4 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-medium text-gray-900">{interest}</h3>
              </div>
              <Button variant="danger" size="sm">Remove</Button>
            </div>
          ))}
        </CardBody>
      </Card>
    </div>
  );
};

const AccountSettings: React.FC = () => {
  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-gray-900">Change Password</h2>
        </CardHeader>
        
        <CardBody className="space-y-6">
          <Input 
            label="Current Password" 
            type="password" 
          />
          
          <Input 
            label="New Password" 
            type="password" 
          />
          
          <Input 
            label="Confirm New Password" 
            type="password" 
          />
          
          <div className="pt-4 flex justify-end">
            <Button variant="primary">
              Update Password
            </Button>
          </div>
        </CardBody>
      </Card>
      
      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-gray-900">Account Management</h2>
        </CardHeader>
        
        <CardBody className="space-y-6">
          <div className="border-b border-gray-200 pb-6">
            <h3 className="text-sm font-medium text-gray-900 mb-2">Export Data</h3>
            <p className="text-sm text-gray-600 mb-4">
              Download a copy of your data. This includes your profile information, skills, and activity history.
            </p>
            <Button variant="outline" size="sm">
              Request Export
            </Button>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-red-600 mb-2">Delete Account</h3>
            <p className="text-sm text-gray-600 mb-4">
              Permanently delete your account and all associated data. This action cannot be undone.
            </p>
            <Button variant="danger" size="sm">
              Delete Account
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
};

const NotificationSettings: React.FC = () => {
  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-900">Notification Preferences</h2>
      </CardHeader>
      
      <CardBody className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-sm font-medium text-gray-900">Email Notifications</h3>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-700">New messages</p>
              <p className="text-xs text-gray-500">Get notified when you receive a new message</p>
            </div>
            <div className="flex items-center h-5">
              <input
                id="new-messages"
                type="checkbox"
                defaultChecked
                className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
              />
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-700">Session reminders</p>
              <p className="text-xs text-gray-500">Get reminded about upcoming sessions</p>
            </div>
            <div className="flex items-center h-5">
              <input
                id="session-reminders"
                type="checkbox"
                defaultChecked
                className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
              />
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-700">New skill matches</p>
              <p className="text-xs text-gray-500">Get notified when there's a new skill match</p>
            </div>
            <div className="flex items-center h-5">
              <input
                id="skill-matches"
                type="checkbox"
                defaultChecked
                className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
              />
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-700">New reviews</p>
              <p className="text-xs text-gray-500">Get notified when someone leaves a review</p>
            </div>
            <div className="flex items-center h-5">
              <input
                id="new-reviews"
                type="checkbox"
                defaultChecked
                className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
              />
            </div>
          </div>
        </div>
        
        <div className="space-y-4 pt-6 border-t border-gray-200">
          <h3 className="text-sm font-medium text-gray-900">Push Notifications</h3>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-700">Enable push notifications</p>
              <p className="text-xs text-gray-500">Receive notifications even when you're not using the app</p>
            </div>
            <div className="flex items-center h-5">
              <input
                id="push-notifications"
                type="checkbox"
                defaultChecked
                className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
              />
            </div>
          </div>
        </div>
        
        <div className="pt-4 flex justify-end">
          <Button variant="primary">
            Save Preferences
          </Button>
        </div>
      </CardBody>
    </Card>
  );
};

export default SettingsPage;