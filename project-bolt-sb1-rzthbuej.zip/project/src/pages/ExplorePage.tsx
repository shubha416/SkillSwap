import React, { useState } from 'react';
import { Search, Filter, Users, Book, X } from 'lucide-react';
import { Card, CardBody } from '../components/ui/Card';
import Button from '../components/ui/Button';
import SkillCard from '../components/skills/SkillCard';
import SkillMatchCard from '../components/skills/SkillMatchCard';
import Badge from '../components/ui/Badge';
import { mockUsers, mockSkillMatches } from '../data/mockData';

const ExplorePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'matches' | 'skills'>('matches');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  const allCategories = [
    'Arts', 'Music', 'Technology', 'Culinary', 'Languages', 
    'Fitness', 'Home & Garden', 'Business', 'Academic'
  ];
  
  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };
  
  const clearFilters = () => {
    setSelectedCategories([]);
    setSearchQuery('');
  };
  
  // Filter skills based on search and categories
  const filteredSkills = mockUsers.flatMap(user => 
    user.skills.filter(skill => {
      const matchesSearch = 
        skill.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        skill.description.toLowerCase().includes(searchQuery.toLowerCase());
        
      const matchesCategory = 
        selectedCategories.length === 0 || 
        selectedCategories.includes(skill.category);
        
      return matchesSearch && matchesCategory;
    }).map(skill => ({ user, skill }))
  );
  
  // Filter matches based on search and categories
  const filteredMatches = mockSkillMatches.filter(match => {
    const matchesSearch = 
      match.skillToLearn.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      match.skillToTeach.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      match.user.name.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesCategory = 
      selectedCategories.length === 0 || 
      selectedCategories.includes(match.skillToLearn.category) ||
      selectedCategories.includes(match.skillToTeach.category);
      
    return matchesSearch && matchesCategory;
  });
  
  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Explore</h1>
        <p className="text-gray-600">
          Discover people with complementary skills and start your learning journey.
        </p>
      </div>
      
      <div className="flex flex-col md:flex-row gap-6 mb-6">
        <div className="flex-1">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search skills, interests, or users..."
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 block w-full"
            />
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button
            variant="outline"
            leftIcon={<Filter className="h-5 w-5" />}
            onClick={() => setIsFilterOpen(!isFilterOpen)}
          >
            Filters {selectedCategories.length > 0 && `(${selectedCategories.length})`}
          </Button>
          
          <div className="hidden md:flex space-x-2">
            <Button
              variant={activeTab === 'matches' ? 'primary' : 'outline'}
              leftIcon={<Users className="h-5 w-5" />}
              onClick={() => setActiveTab('matches')}
            >
              Matches
            </Button>
            <Button
              variant={activeTab === 'skills' ? 'primary' : 'outline'}
              leftIcon={<Book className="h-5 w-5" />}
              onClick={() => setActiveTab('skills')}
            >
              Skills
            </Button>
          </div>
        </div>
      </div>
      
      <div className="md:hidden mb-6 flex space-x-2">
        <Button
          variant={activeTab === 'matches' ? 'primary' : 'outline'}
          leftIcon={<Users className="h-5 w-5" />}
          onClick={() => setActiveTab('matches')}
          fullWidth
        >
          Matches
        </Button>
        <Button
          variant={activeTab === 'skills' ? 'primary' : 'outline'}
          leftIcon={<Book className="h-5 w-5" />}
          onClick={() => setActiveTab('skills')}
          fullWidth
        >
          Skills
        </Button>
      </div>
      
      {isFilterOpen && (
        <Card className="mb-6">
          <CardBody className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Filters</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
              >
                Clear all
              </Button>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Categories</h4>
              <div className="flex flex-wrap gap-2">
                {allCategories.map(category => (
                  <button
                    key={category}
                    onClick={() => toggleCategory(category)}
                    className={`
                      px-3 py-1 rounded-full text-sm font-medium
                      ${selectedCategories.includes(category)
                        ? 'bg-primary-100 text-primary-800'
                        : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}
                    `}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </CardBody>
        </Card>
      )}
      
      {(selectedCategories.length > 0 || searchQuery) && (
        <div className="mb-6 flex items-center">
          <span className="text-sm text-gray-600 mr-2">Active filters:</span>
          <div className="flex flex-wrap gap-2">
            {searchQuery && (
              <Badge className="flex items-center">
                Search: {searchQuery}
                <button
                  onClick={() => setSearchQuery('')}
                  className="ml-1"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            
            {selectedCategories.map(category => (
              <Badge key={category} className="flex items-center">
                {category}
                <button
                  onClick={() => toggleCategory(category)}
                  className="ml-1"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>
      )}
      
      {activeTab === 'matches' ? (
        <div className="space-y-6">
          <h2 className="text-xl font-semibold text-gray-900">
            Skill Matches ({filteredMatches.length})
          </h2>
          
          {filteredMatches.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredMatches.map(match => (
                <SkillMatchCard key={match.id} match={match} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">No matches found</h3>
              <p className="text-gray-500">
                Try adjusting your search or filters to find more skill matches.
              </p>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          <h2 className="text-xl font-semibold text-gray-900">
            Available Skills ({filteredSkills.length})
          </h2>
          
          {filteredSkills.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {filteredSkills.map(({ user, skill }, index) => (
                <SkillCard key={`${user.id}-${skill.id}-${index}`} user={user} skill={skill} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <Book className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">No skills found</h3>
              <p className="text-gray-500">
                Try adjusting your search or filters to find more skills.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ExplorePage;