import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, BookOpen, Calendar, Shield, MessageSquare } from 'lucide-react';
import Button from '../components/ui/Button';
import { Card, CardBody } from '../components/ui/Card';
import { useAuth } from '../context/AuthContext';
import SkillMatchCard from '../components/skills/SkillMatchCard';
import { mockSkillMatches } from '../data/mockData';

const HomePage: React.FC = () => {
  const { isAuthenticated, currentUser } = useAuth();
  
  return (
    <div className="max-w-7xl mx-auto">
      {!isAuthenticated ? (
        <div className="space-y-12">
          <section className="text-center py-12 md:py-20">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Share Knowledge, <span className="text-primary-500">Grow Together</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              SkillSwap connects people who want to exchange skills and knowledge.
              Teach what you know, learn what you want, and make meaningful connections.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/register">
                <Button 
                  size="lg" 
                  variant="primary" 
                  className="font-medium"
                >
                  Get Started
                </Button>
              </Link>
              <Link to="/explore">
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="font-medium"
                  rightIcon={<ArrowRight className="ml-1 h-5 w-5" />}
                >
                  Explore Skills
                </Button>
              </Link>
            </div>
          </section>
          
          <section className="py-12 bg-gray-50 rounded-lg">
            <div className="max-w-6xl mx-auto px-4">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                How SkillSwap Works
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 text-center">
                  <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="h-8 w-8 text-primary-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">1. Create Your Profile</h3>
                  <p className="text-gray-600">
                    Share the skills you can teach and what you want to learn. The more detailed your profile, the better your matches.
                  </p>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 text-center">
                  <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="h-8 w-8 text-secondary-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">2. Match with Others</h3>
                  <p className="text-gray-600">
                    Our algorithm finds people who can teach what you want to learn, and learn what you can teach.
                  </p>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 text-center">
                  <div className="w-16 h-16 bg-accent-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Calendar className="h-8 w-8 text-accent-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">3. Schedule Sessions</h3>
                  <p className="text-gray-600">
                    Connect through messages and schedule virtual or in-person skill exchange sessions.
                  </p>
                </div>
              </div>
            </div>
          </section>
          
          <section className="py-12">
            <div className="max-w-6xl mx-auto px-4">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                Why Choose SkillSwap?
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card>
                  <CardBody className="p-6">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                          <Shield className="h-6 w-6 text-primary-600" />
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">Verified Profiles</h3>
                        <p className="text-gray-600">
                          Our verification system ensures that you're connecting with real people who are passionate about skill sharing.
                        </p>
                      </div>
                    </div>
                  </CardBody>
                </Card>
                
                <Card>
                  <CardBody className="p-6">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-secondary-100 rounded-full flex items-center justify-center">
                          <Users className="h-6 w-6 text-secondary-600" />
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">Community Focused</h3>
                        <p className="text-gray-600">
                          Build meaningful connections while learning and teaching. Our platform encourages long-term skill exchange relationships.
                        </p>
                      </div>
                    </div>
                  </CardBody>
                </Card>
                
                <Card>
                  <CardBody className="p-6">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-accent-100 rounded-full flex items-center justify-center">
                          <MessageSquare className="h-6 w-6 text-accent-600" />
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">Seamless Communication</h3>
                        <p className="text-gray-600">
                          Our integrated messaging and scheduling tools make it easy to coordinate skill exchange sessions.
                        </p>
                      </div>
                    </div>
                  </CardBody>
                </Card>
                
                <Card>
                  <CardBody className="p-6">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                          <Calendar className="h-6 w-6 text-primary-600" />
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">Flexible Scheduling</h3>
                        <p className="text-gray-600">
                          Choose between virtual or in-person sessions based on your preference and availability.
                        </p>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </div>
            </div>
          </section>
          
          <section className="py-12 bg-primary-50 rounded-lg">
            <div className="max-w-5xl mx-auto px-4 text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Ready to start your skill-sharing journey?
              </h2>
              <p className="text-lg text-gray-600 mb-8 max-w-3xl mx-auto">
                Join thousands of people who are already exchanging skills and growing together.
              </p>
              <Link to="/register">
                <Button 
                  size="lg" 
                  variant="primary" 
                  className="font-medium"
                >
                  Sign Up Now
                </Button>
              </Link>
            </div>
          </section>
        </div>
      ) : (
        <div className="space-y-8">
          <section>
            <h1 className="text-2xl font-bold text-gray-900 mb-6">
              Welcome back, {currentUser?.name}!
            </h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardBody className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Stats</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Skills</span>
                      <span className="font-medium text-gray-900">{currentUser?.skills.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Interests</span>
                      <span className="font-medium text-gray-900">{currentUser?.interests.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Rating</span>
                      <span className="font-medium text-gray-900">{currentUser?.rating.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Reviews</span>
                      <span className="font-medium text-gray-900">{currentUser?.reviewCount}</span>
                    </div>
                  </div>
                </CardBody>
              </Card>
              
              <Card className="md:col-span-2">
                <CardBody className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">Upcoming Sessions</h3>
                    <Link to="/schedule">
                      <Button variant="outline" size="sm">View All</Button>
                    </Link>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center p-3 bg-primary-50 rounded-lg">
                      <div className="flex-shrink-0">
                        <Calendar className="h-10 w-10 text-primary-500" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-900">
                          Photography Basics with Emma
                        </p>
                        <p className="text-xs text-gray-500">
                          Tomorrow, 2:00 PM - 3:00 PM
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center p-3 bg-primary-50 rounded-lg">
                      <div className="flex-shrink-0">
                        <Calendar className="h-10 w-10 text-primary-500" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-900">
                          Spanish Cooking with Daniel
                        </p>
                        <p className="text-xs text-gray-500">
                          Friday, 5:00 PM - 6:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </div>
          </section>
          
          <section>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">Your Top Matches</h2>
              <Link to="/explore">
                <Button variant="outline" size="sm" rightIcon={<ArrowRight className="h-4 w-4" />}>
                  View All
                </Button>
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mockSkillMatches.slice(0, 2).map((match) => (
                <SkillMatchCard key={match.id} match={match} />
              ))}
            </div>
          </section>
        </div>
      )}
    </div>
  );
};

export default HomePage;