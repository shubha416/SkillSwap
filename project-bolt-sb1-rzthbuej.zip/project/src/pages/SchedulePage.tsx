import React, { useState } from 'react';
import { User, Clock, MapPin, Video } from 'lucide-react';
import { Calendar as CalendarIcon } from 'lucide-react';
import Calendar from '../components/schedule/Calendar';
import Button from '../components/ui/Button';
import { Card, CardHeader, CardBody } from '../components/ui/Card';
import { mockScheduledSessions } from '../data/mockData';
import { ScheduledSession } from '../types';
import { format, parseISO } from 'date-fns';

const SchedulePage: React.FC = () => {
  const [selectedSession, setSelectedSession] = useState<ScheduledSession | null>(null);
  
  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2 md:mb-0">Schedule</h1>
        <Button variant="primary" leftIcon={<CalendarIcon className="h-4 w-4" />}>
          Create New Session
        </Button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Calendar 
            sessions={mockScheduledSessions} 
            onSelectSession={setSelectedSession} 
          />
        </div>
        
        <div>
          {selectedSession ? (
            <Card>
              <CardHeader className="flex justify-between items-center">
                <h2 className="text-lg font-semibold text-gray-900">Session Details</h2>
                <Button variant="outline" size="sm">Edit</Button>
              </CardHeader>
              
              <CardBody className="space-y-4">
                <div>
                  <h3 className="text-xl font-medium text-gray-900 mb-2">
                    {selectedSession.title}
                  </h3>
                  <span 
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      selectedSession.status === 'completed' 
                        ? 'bg-green-100 text-green-800' 
                        : selectedSession.status === 'cancelled' 
                          ? 'bg-red-100 text-red-800' 
                          : 'bg-primary-100 text-primary-800'
                    }`}
                  >
                    {selectedSession.status.charAt(0).toUpperCase() + selectedSession.status.slice(1)}
                  </span>
                </div>
                
                <div className="flex items-center text-gray-700">
                  <CalendarIcon className="h-5 w-5 mr-2 text-gray-500" />
                  <span>
                    {format(parseISO(selectedSession.start), 'EEEE, MMMM d, yyyy')}
                  </span>
                </div>
                
                <div className="flex items-center text-gray-700">
                  <Clock className="h-5 w-5 mr-2 text-gray-500" />
                  <span>
                    {format(parseISO(selectedSession.start), 'h:mm a')} - {format(parseISO(selectedSession.end), 'h:mm a')}
                  </span>
                </div>
                
                <div className="flex items-center text-gray-700">
                  {selectedSession.isVirtual ? (
                    <>
                      <Video className="h-5 w-5 mr-2 text-gray-500" />
                      <span>Virtual Session ({selectedSession.location})</span>
                    </>
                  ) : (
                    <>
                      <MapPin className="h-5 w-5 mr-2 text-gray-500" />
                      <span>{selectedSession.location}</span>
                    </>
                  )}
                </div>
                
                <div className="flex items-center text-gray-700">
                  <User className="h-5 w-5 mr-2 text-gray-500" />
                  <span>
                    {selectedSession.teacherId === 'user-1' ? 'You are teaching' : 'You are learning'}
                  </span>
                </div>
                
                <div className="pt-4 border-t border-gray-200 flex space-x-2">
                  {selectedSession.status === 'scheduled' && (
                    <>
                      <Button variant="outline" size="sm" fullWidth>
                        Reschedule
                      </Button>
                      <Button variant="danger" size="sm" fullWidth>
                        Cancel
                      </Button>
                    </>
                  )}
                  
                  {selectedSession.status === 'completed' && (
                    <Button variant="primary" size="sm" fullWidth>
                      Leave Review
                    </Button>
                  )}
                </div>
              </CardBody>
            </Card>
          ) : (
            <Card>
              <CardBody className="p-6 text-center">
                <CalendarIcon className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  No session selected
                </h3>
                <p className="text-gray-600 mb-4">
                  Select a session from the calendar to view details.
                </p>
                <Button variant="outline" fullWidth>
                  Create New Session
                </Button>
              </CardBody>
            </Card>
          )}
          
          <div className="mt-6">
            <Card>
              <CardHeader>
                <h2 className="text-lg font-semibold text-gray-900">Upcoming Sessions</h2>
              </CardHeader>
              
              <CardBody className="divide-y divide-gray-200">
                {mockScheduledSessions
                  .filter(session => session.status === 'scheduled')
                  .slice(0, 3)
                  .map(session => (
                    <div 
                      key={session.id}
                      className="py-4 cursor-pointer hover:bg-gray-50"
                      onClick={() => setSelectedSession(session)}
                    >
                      <div className="flex items-start">
                        <div className="flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary-500" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">
                            {session.title}
                          </p>
                          <p className="text-xs text-gray-500">
                            {format(parseISO(session.start), 'EEE, MMM d')} • {format(parseISO(session.start), 'h:mm a')}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                
                {mockScheduledSessions.filter(session => session.status === 'scheduled').length === 0 && (
                  <div className="py-4 text-center text-gray-500">
                    No upcoming sessions
                  </div>
                )}
              </CardBody>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SchedulePage;