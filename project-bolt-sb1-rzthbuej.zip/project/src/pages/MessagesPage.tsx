import React, { useState } from 'react';
import ConversationList from '../components/messages/ConversationList';
import MessageThread from '../components/messages/MessageThread';
import { mockConversations } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

const MessagesPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  
  const activeConversation = activeConversationId 
    ? mockConversations.find(conv => conv.id === activeConversationId) 
    : null;
  
  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Messages</h1>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-3 h-[600px]">
          <div className="md:col-span-1 border-r border-gray-200">
            <ConversationList 
              conversations={mockConversations}
              activeConversationId={activeConversationId}
              onSelectConversation={setActiveConversationId}
            />
          </div>
          
          <div className="md:col-span-2 h-full">
            {currentUser && (
              <MessageThread 
                conversation={activeConversation}
                currentUser={currentUser}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessagesPage;