import { User, Skill, SkillMatch, Conversation, Review, ScheduledSession } from '../types';

// Mock Users
export const mockUsers: User[] = [
  {
    id: 'user-1',
    name: 'Alex Johnson',
    avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Professional photographer and amateur chef. Passionate about teaching others and expanding my own skill set.',
    location: 'San Francisco, CA',
    isVerified: true,
    skills: [
      {
        id: 'skill-1',
        name: 'Photography',
        category: 'Arts',
        description: 'DSLR photography techniques, composition, and post-processing in Adobe Lightroom and Photoshop.',
        proficiency: 'expert',
      },
      {
        id: 'skill-2',
        name: 'Spanish Cooking',
        category: 'Culinary',
        description: 'Authentic paella, tapas, and other traditional Spanish dishes.',
        proficiency: 'intermediate',
      },
    ],
    interests: ['Piano', 'French Language', 'Web Development'],
    rating: 4.8,
    reviewCount: 24,
  },
  {
    id: 'user-2',
    name: 'Emma Wilson',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Piano teacher and language enthusiast. I love connecting with people from different cultures.',
    location: 'Boston, MA',
    isVerified: true,
    skills: [
      {
        id: 'skill-3',
        name: 'Piano',
        category: 'Music',
        description: 'Classical piano techniques, music theory, and performance skills.',
        proficiency: 'expert',
      },
      {
        id: 'skill-4',
        name: 'French Language',
        category: 'Languages',
        description: 'Conversational French, grammar, and pronunciation.',
        proficiency: 'advanced',
      },
    ],
    interests: ['Photography', 'Spanish Cooking', 'Yoga'],
    rating: 4.9,
    reviewCount: 31,
  },
  {
    id: 'user-3',
    name: 'Daniel Brown',
    avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Software engineer and fitness enthusiast. I believe in continuous learning and personal growth.',
    location: 'Austin, TX',
    isVerified: false,
    skills: [
      {
        id: 'skill-5',
        name: 'Web Development',
        category: 'Technology',
        description: 'Front-end development with React, responsive design, and modern JavaScript.',
        proficiency: 'expert',
      },
      {
        id: 'skill-6',
        name: 'Fitness Training',
        category: 'Fitness',
        description: 'Strength training, HIIT workouts, and nutrition planning.',
        proficiency: 'advanced',
      },
    ],
    interests: ['Piano', 'Spanish Cooking', 'Gardening'],
    rating: 4.6,
    reviewCount: 12,
  },
  {
    id: 'user-4',
    name: 'Sophia Martinez',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Yoga instructor and gardening enthusiast. I love sharing my knowledge and learning new skills.',
    location: 'Portland, OR',
    isVerified: true,
    skills: [
      {
        id: 'skill-7',
        name: 'Yoga',
        category: 'Fitness',
        description: 'Hatha and Vinyasa yoga, meditation, and mindfulness practices.',
        proficiency: 'expert',
      },
      {
        id: 'skill-8',
        name: 'Gardening',
        category: 'Home & Garden',
        description: 'Organic vegetable gardening, composting, and sustainable practices.',
        proficiency: 'advanced',
      },
    ],
    interests: ['Web Development', 'Photography', 'French Language'],
    rating: 4.7,
    reviewCount: 19,
  },
];

// Mock Skill Matches
export const mockSkillMatches: SkillMatch[] = [
  {
    id: 'match-1',
    user: mockUsers[1], // Emma Wilson
    skillToTeach: mockUsers[1].skills[0], // Piano
    skillToLearn: mockUsers[0].skills[0], // Photography
    compatibility: 92,
  },
  {
    id: 'match-2',
    user: mockUsers[2], // Daniel Brown
    skillToTeach: mockUsers[2].skills[0], // Web Development
    skillToLearn: mockUsers[0].skills[1], // Spanish Cooking
    compatibility: 85,
  },
  {
    id: 'match-3',
    user: mockUsers[3], // Sophia Martinez
    skillToTeach: mockUsers[3].skills[0], // Yoga
    skillToLearn: mockUsers[0].skills[0], // Photography
    compatibility: 78,
  },
];

// Mock Conversations
export const mockConversations: Conversation[] = [
  {
    id: 'conv-1',
    participants: [mockUsers[0], mockUsers[1]],
    lastMessage: {
      id: 'msg-1',
      senderId: mockUsers[1].id,
      receiverId: mockUsers[0].id,
      content: 'That sounds like a perfect skill swap! When are you available for our first session?',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      isRead: false,
    },
    unreadCount: 1,
  },
  {
    id: 'conv-2',
    participants: [mockUsers[0], mockUsers[2]],
    lastMessage: {
      id: 'msg-2',
      senderId: mockUsers[0].id,
      receiverId: mockUsers[2].id,
      content: 'I\'d be happy to teach you photography basics. Let me know when you\'re free!',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
      isRead: true,
    },
    unreadCount: 0,
  },
  {
    id: 'conv-3',
    participants: [mockUsers[0], mockUsers[3]],
    lastMessage: {
      id: 'msg-3',
      senderId: mockUsers[3].id,
      receiverId: mockUsers[0].id,
      content: 'Thanks for the yoga session yesterday! I really enjoyed it.',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
      isRead: true,
    },
    unreadCount: 0,
  },
];

// Mock Reviews
export const mockReviews: Review[] = [
  {
    id: 'review-1',
    authorId: mockUsers[1].id,
    recipientId: mockUsers[0].id,
    content: 'Alex is an amazing photography teacher! Very patient and knowledgeable. I learned so much in just one session.',
    rating: 5,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(),
  },
  {
    id: 'review-2',
    authorId: mockUsers[2].id,
    recipientId: mockUsers[0].id,
    content: 'Great experience learning Spanish cooking. The paella recipe was delicious!',
    rating: 4,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString(),
  },
  {
    id: 'review-3',
    authorId: mockUsers[3].id,
    recipientId: mockUsers[0].id,
    content: 'Excellent photography tips. Alex makes complex concepts very easy to understand.',
    rating: 5,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 21).toISOString(),
  },
];

// Mock Scheduled Sessions
export const mockScheduledSessions: ScheduledSession[] = [
  {
    id: 'session-1',
    title: 'Photography Basics with Emma',
    teacherId: mockUsers[0].id,
    studentId: mockUsers[1].id,
    skillId: mockUsers[0].skills[0].id,
    start: new Date(Date.now() + 1000 * 60 * 60 * 48).toISOString(),
    end: new Date(Date.now() + 1000 * 60 * 60 * 49).toISOString(),
    location: 'Zoom',
    isVirtual: true,
    status: 'scheduled',
  },
  {
    id: 'session-2',
    title: 'Spanish Cooking with Daniel',
    teacherId: mockUsers[0].id,
    studentId: mockUsers[2].id,
    skillId: mockUsers[0].skills[1].id,
    start: new Date(Date.now() + 1000 * 60 * 60 * 72).toISOString(),
    end: new Date(Date.now() + 1000 * 60 * 60 * 73).toISOString(),
    location: 'Daniel\'s Kitchen',
    isVirtual: false,
    status: 'scheduled',
  },
  {
    id: 'session-3',
    title: 'Photography Workshop with Sophia',
    teacherId: mockUsers[0].id,
    studentId: mockUsers[3].id,
    skillId: mockUsers[0].skills[0].id,
    start: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    end: new Date(Date.now() - 1000 * 60 * 60 * 23).toISOString(),
    location: 'Golden Gate Park',
    isVirtual: false,
    status: 'completed',
  },
];