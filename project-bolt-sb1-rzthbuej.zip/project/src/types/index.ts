export interface User {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  location: string;
  isVerified: boolean;
  skills: Skill[];
  interests: string[];
  rating: number;
  reviewCount: number;
}

export interface Skill {
  id: string;
  name: string;
  category: string;
  description: string;
  proficiency: 'beginner' | 'intermediate' | 'advanced' | 'expert';
}

export interface SkillMatch {
  id: string;
  user: User;
  skillToTeach: Skill;
  skillToLearn: Skill;
  compatibility: number;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

export interface Conversation {
  id: string;
  participants: User[];
  lastMessage: Message;
  unreadCount: number;
}

export interface Review {
  id: string;
  authorId: string;
  recipientId: string;
  content: string;
  rating: number;
  timestamp: string;
}

export interface ScheduledSession {
  id: string;
  title: string;
  teacherId: string;
  studentId: string;
  skillId: string;
  start: string;
  end: string;
  location: string;
  isVirtual: boolean;
  status: 'scheduled' | 'completed' | 'cancelled';
}