import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  Search, 
  Calendar, 
  MessageSquare, 
  User, 
  Settings,
  Award
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Sidebar: React.FC = () => {
  const location = useLocation();
  const { currentUser } = useAuth();

  const navigationItems = [
    { name: 'Home', icon: Home, href: '/' },
    { name: 'Explore', icon: Search, href: '/explore' },
    { name: 'Schedule', icon: Calendar, href: '/schedule' },
    { name: 'Messages', icon: MessageSquare, href: '/messages' },
    { name: 'Profile', icon: User, href: `/profile/${currentUser?.id}` },
    { name: 'Settings', icon: Settings, href: '/settings' },
  ];

  return (
    <div className="h-full py-6 px-3 bg-white">
      <div className="space-y-8">
        <div>
          <ul className="space-y-2">
            {navigationItems.map((item) => (
              <li key={item.name}>
                <Link
                  to={item.href}
                  className={`flex items-center p-3 text-sm font-medium rounded-lg ${
                    location.pathname === item.href
                      ? 'text-primary-500 bg-primary-50'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <item.icon className="h-5 w-5 mr-3" />
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="px-3">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
            My Skills
          </h3>
          <div className="mt-2 space-y-1">
            {currentUser?.skills.slice(0, 3).map((skill) => (
              <Link
                key={skill.id}
                to={`/skills/${skill.id}`}
                className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-100"
              >
                <span className="w-2 h-2 mr-3 bg-accent-500 rounded-full"></span>
                {skill.name}
              </Link>
            ))}
            <Link
              to="/settings/skills"
              className="flex items-center px-3 py-2 text-sm font-medium text-primary-500 rounded-lg hover:bg-gray-100"
            >
              + Add skill
            </Link>
          </div>
        </div>
        
        <div className="px-3">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Learning
          </h3>
          <div className="mt-2 space-y-1">
            {currentUser?.interests.slice(0, 3).map((interest, index) => (
              <Link
                key={index}
                to={`/skills/learn/${interest.replace(/\s+/g, '-').toLowerCase()}`}
                className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-100"
              >
                <span className="w-2 h-2 mr-3 bg-secondary-500 rounded-full"></span>
                {interest}
              </Link>
            ))}
            <Link
              to="/settings/interests"
              className="flex items-center px-3 py-2 text-sm font-medium text-primary-500 rounded-lg hover:bg-gray-100"
            >
              + Add interest
            </Link>
          </div>
        </div>
        
        {currentUser?.isVerified && (
          <div className="px-6">
            <div className="flex items-center p-3 bg-primary-50 rounded-lg">
              <Award className="h-5 w-5 text-primary-500 mr-2" />
              <span className="text-sm font-medium text-primary-700">
                Verified Member
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;