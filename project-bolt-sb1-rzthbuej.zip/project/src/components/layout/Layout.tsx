import React from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import { useAuth } from '../../context/AuthContext';

const Layout: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        {isAuthenticated && (
          <div className="hidden md:block w-64 min-h-[calc(100vh-64px)] border-r border-gray-200">
            <Sidebar />
          </div>
        )}
        <main className={`flex-1 p-4 md:p-8 ${isAuthenticated ? '' : 'max-w-7xl mx-auto'}`}>
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;