import React from 'react';
import { Search } from 'lucide-react';
import Avatar from '../ui/Avatar';
import { Conversation } from '../../types';
import { format } from 'date-fns';

interface ConversationListProps {
  conversations: Conversation[];
  activeConversationId: string | null;
  onSelectConversation: (conversationId: string) => void;
}

const ConversationList: React.FC<ConversationListProps> = ({
  conversations,
  activeConversationId,
  onSelectConversation,
}) => {
  return (
    <div className="bg-white border-r border-gray-200 h-full">
      <div className="p-4 border-b border-gray-200">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search messages"
            className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 block w-full text-sm"
          />
        </div>
      </div>
      
      <div className="overflow-y-auto h-[calc(100%-4rem)]">
        {conversations.map((conversation) => {
          const otherParticipant = conversation.participants.find(
            (p) => p.id !== 'current-user-id'
          );
          
          if (!otherParticipant) return null;
          
          const lastMessageDate = new Date(conversation.lastMessage.timestamp);
          const isToday = new Date().toDateString() === lastMessageDate.toDateString();
          const formattedDate = isToday 
            ? format(lastMessageDate, 'h:mm a') 
            : format(lastMessageDate, 'MM/dd/yyyy');
          
          return (
            <div
              key={conversation.id}
              className={`
                p-4 cursor-pointer hover:bg-gray-50 border-b border-gray-200
                ${activeConversationId === conversation.id ? 'bg-primary-50 hover:bg-primary-50' : ''}
              `}
              onClick={() => onSelectConversation(conversation.id)}
            >
              <div className="flex items-start">
                <div className="relative">
                  <Avatar 
                    src={otherParticipant.avatar} 
                    name={otherParticipant.name} 
                    size="md" 
                    status={conversation.unreadCount > 0 ? 'online' : 'none'}
                  />
                </div>
                
                <div className="ml-3 flex-1 min-w-0">
                  <div className="flex justify-between">
                    <p className={`text-sm font-medium ${conversation.unreadCount > 0 ? 'text-gray-900' : 'text-gray-800'}`}>
                      {otherParticipant.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formattedDate}
                    </p>
                  </div>
                  
                  <p className={`text-sm truncate ${conversation.unreadCount > 0 ? 'font-medium text-gray-900' : 'text-gray-600'}`}>
                    {conversation.lastMessage.content}
                  </p>
                  
                  {conversation.unreadCount > 0 && (
                    <div className="mt-1 flex items-center">
                      <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-primary-500 text-xs font-medium text-white">
                        {conversation.unreadCount}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ConversationList;