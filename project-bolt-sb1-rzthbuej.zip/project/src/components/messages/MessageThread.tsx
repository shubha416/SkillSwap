import React, { useState, useRef, useEffect } from 'react';
import { Send, Phone, Video, MoreHorizontal } from 'lucide-react';
import Avatar from '../ui/Avatar';
import Button from '../ui/Button';
import { Conversation, Message, User } from '../../types';
import { format } from 'date-fns';

interface MessageThreadProps {
  conversation: Conversation | null;
  currentUser: User;
}

const MessageThread: React.FC<MessageThreadProps> = ({
  conversation,
  currentUser,
}) => {
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    scrollToBottom();
  }, [conversation]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !conversation) return;
    
    // Here you would typically send the message to an API
    console.log('Sending message:', newMessage);
    
    // Clear the input field
    setNewMessage('');
  };
  
  if (!conversation) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-lg font-medium text-gray-500">Select a conversation to start messaging</p>
        </div>
      </div>
    );
  }
  
  const otherParticipant = conversation.participants.find(
    (p) => p.id !== currentUser.id
  );
  
  if (!otherParticipant) return null;
  
  // Mocked messages for the UI
  const messages: Message[] = [
    {
      id: '1',
      senderId: otherParticipant.id,
      receiverId: currentUser.id,
      content: 'Hi there! I saw you\'re interested in learning photography.',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
      isRead: true,
    },
    {
      id: '2',
      senderId: currentUser.id,
      receiverId: otherParticipant.id,
      content: 'Yes! I\'ve been wanting to learn DSLR photography for a while now.',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 23).toISOString(),
      isRead: true,
    },
    {
      id: '3',
      senderId: otherParticipant.id,
      receiverId: currentUser.id,
      content: 'That\'s great! I\'d be happy to teach you the basics. I\'ve been doing photography for about 5 years now.',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 22).toISOString(),
      isRead: true,
    },
    {
      id: '4',
      senderId: currentUser.id,
      receiverId: otherParticipant.id,
      content: 'Awesome! I saw that you\'re interested in learning Spanish cooking. I\'d be happy to teach you some recipes.',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 21).toISOString(),
      isRead: true,
    },
    {
      id: '5',
      senderId: otherParticipant.id,
      receiverId: currentUser.id,
      content: 'That sounds like a perfect skill swap! When are you available for our first session?',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 20).toISOString(),
      isRead: true,
    },
  ];
  
  return (
    <div className="flex flex-col h-full bg-white">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200">
        <div className="flex items-center">
          <Avatar 
            src={otherParticipant.avatar} 
            name={otherParticipant.name} 
            size="md" 
            status="online"
          />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-gray-900">
              {otherParticipant.name}
              {otherParticipant.isVerified && (
                <span className="ml-1 text-primary-500" title="Verified User">✓</span>
              )}
            </h3>
            <p className="text-xs text-gray-500">Online</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button className="p-2 rounded-full hover:bg-gray-100">
            <Phone className="h-5 w-5 text-gray-600" />
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100">
            <Video className="h-5 w-5 text-gray-600" />
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100">
            <MoreHorizontal className="h-5 w-5 text-gray-600" />
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
        <div className="space-y-4">
          {messages.map((message) => {
            const isCurrentUser = message.senderId === currentUser.id;
            const messageDate = new Date(message.timestamp);
            const formattedDate = format(messageDate, 'MMM d, h:mm a');
            
            return (
              <div 
                key={message.id} 
                className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className="flex max-w-[70%]">
                  {!isCurrentUser && (
                    <div className="self-end mb-2 mr-2">
                      <Avatar 
                        src={otherParticipant.avatar} 
                        name={otherParticipant.name} 
                        size="sm" 
                      />
                    </div>
                  )}
                  
                  <div>
                    <div 
                      className={`
                        px-4 py-2 rounded-lg
                        ${isCurrentUser 
                          ? 'bg-primary-500 text-white' 
                          : 'bg-white border border-gray-200 text-gray-800'}
                      `}
                    >
                      <p className="text-sm">{message.content}</p>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{formattedDate}</p>
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      <form 
        onSubmit={handleSendMessage}
        className="px-4 py-3 border-t border-gray-200"
      >
        <div className="flex items-center">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 border border-gray-300 rounded-l-md py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
          />
          <Button
            type="submit"
            variant="primary"
            className="rounded-l-none rounded-r-md"
            disabled={!newMessage.trim()}
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </form>
    </div>
  );
};

export default MessageThread;