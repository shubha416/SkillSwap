import React from 'react';
import { Card, CardBody, CardFooter } from '../ui/Card';
import Avatar from '../ui/Avatar';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { Calendar, MessageSquare } from 'lucide-react';
import { SkillMatch } from '../../types';
import { Link } from 'react-router-dom';

interface SkillMatchCardProps {
  match: SkillMatch;
}

const SkillMatchCard: React.FC<SkillMatchCardProps> = ({ match }) => {
  const { user, skillToTeach, skillToLearn, compatibility } = match;
  
  return (
    <Card hoverable className="h-full">
      <CardBody>
        <div className="flex items-start space-x-4">
          <Link to={`/profile/${user.id}`}>
            <Avatar src={user.avatar} name={user.name} size="lg" status="online" />
          </Link>
          
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <Link to={`/profile/${user.id}`} className="group">
                <h3 className="text-lg font-semibold text-gray-900 group-hover:text-primary-600">
                  {user.name}
                  {user.isVerified && (
                    <span className="ml-1 text-primary-500" title="Verified User">✓</span>
                  )}
                </h3>
              </Link>
              
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Badge variant="primary" size="md" className="font-semibold">
                    {compatibility}% Match
                  </Badge>
                </div>
              </div>
            </div>
            
            <p className="mt-1 text-sm text-gray-500">
              {user.location}
            </p>
            
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="border border-gray-200 rounded-md p-3">
                <div className="flex items-center mb-2">
                  <span className="flex h-6 w-6 rounded-full bg-secondary-100 text-secondary-600 items-center justify-center text-xs font-medium">
                    ↓
                  </span>
                  <h4 className="ml-2 text-sm font-medium text-gray-900">You'll Learn</h4>
                </div>
                <p className="text-sm font-medium text-gray-800">{skillToLearn.name}</p>
                <Badge variant="secondary" size="sm" className="mt-2">
                  {skillToLearn.proficiency}
                </Badge>
              </div>
              
              <div className="border border-gray-200 rounded-md p-3">
                <div className="flex items-center mb-2">
                  <span className="flex h-6 w-6 rounded-full bg-accent-100 text-accent-600 items-center justify-center text-xs font-medium">
                    ↑
                  </span>
                  <h4 className="ml-2 text-sm font-medium text-gray-900">You'll Teach</h4>
                </div>
                <p className="text-sm font-medium text-gray-800">{skillToTeach.name}</p>
                <Badge variant="accent" size="sm" className="mt-2">
                  {skillToTeach.proficiency}
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </CardBody>
      
      <CardFooter className="flex justify-between bg-gray-50">
        <Button 
          variant="outline" 
          size="sm"
          leftIcon={<MessageSquare className="w-4 h-4" />}
        >
          Message
        </Button>
        
        <Button 
          variant="primary" 
          size="sm"
          leftIcon={<Calendar className="w-4 h-4" />}
        >
          Schedule
        </Button>
      </CardFooter>
    </Card>
  );
};

export default SkillMatchCard;