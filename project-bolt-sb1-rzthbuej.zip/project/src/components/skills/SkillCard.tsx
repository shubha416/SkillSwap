import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Star } from 'lucide-react';
import { Card, CardBody } from '../ui/Card';
import Avatar from '../ui/Avatar';
import Badge from '../ui/Badge';
import { User, Skill } from '../../types';

interface SkillCardProps {
  user: User;
  skill: Skill;
}

const SkillCard: React.FC<SkillCardProps> = ({ user, skill }) => {
  const proficiencyColor = {
    beginner: 'gray',
    intermediate: 'accent',
    advanced: 'secondary',
    expert: 'primary',
  };
  
  return (
    <Card hoverable className="h-full transition-transform duration-200 hover:scale-[1.02]">
      <CardBody>
        <div className="flex items-start justify-between mb-4">
          <Link to={`/profile/${user.id}`} className="flex items-center">
            <Avatar src={user.avatar} name={user.name} size="md" />
            <div className="ml-3">
              <h3 className="text-sm font-medium text-gray-900">
                {user.name}
                {user.isVerified && (
                  <span className="ml-1 text-primary-500" title="Verified User">✓</span>
                )}
              </h3>
              <p className="text-xs text-gray-500">{user.location}</p>
            </div>
          </Link>
          <div className="flex items-center">
            <Star className="w-4 h-4 text-accent-500 mr-1" />
            <span className="text-sm font-medium">{user.rating.toFixed(1)}</span>
          </div>
        </div>
        
        <h2 className="text-base font-semibold text-gray-900 mb-2">
          {skill.name}
        </h2>
        
        <p className="text-sm text-gray-600 mb-4 line-clamp-3">
          {skill.description}
        </p>
        
        <div className="flex items-center justify-between">
          <Badge 
            variant={proficiencyColor[skill.proficiency] as any}
            size="sm"
          >
            {skill.proficiency.charAt(0).toUpperCase() + skill.proficiency.slice(1)}
          </Badge>
          
          <div className="flex items-center text-xs text-gray-500">
            <Clock className="w-3 h-3 mr-1" />
            <span>60 min session</span>
          </div>
        </div>
      </CardBody>
    </Card>
  );
};

export default SkillCard;