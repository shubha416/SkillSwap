import React from 'react';
import { Skill } from '../../types';
import Badge from '../ui/Badge';
import { Card, CardHeader, CardBody } from '../ui/Card';

interface SkillListProps {
  title: string;
  skills: Skill[];
  emptyMessage: string;
}

const SkillList: React.FC<SkillListProps> = ({ 
  title, 
  skills, 
  emptyMessage 
}) => {
  const proficiencyColor = {
    beginner: 'gray',
    intermediate: 'accent',
    advanced: 'secondary',
    expert: 'primary',
  };
  
  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
      </CardHeader>
      <CardBody>
        {skills.length > 0 ? (
          <div className="space-y-6">
            {skills.map((skill) => (
              <div key={skill.id} className="border-b border-gray-200 last:border-b-0 pb-4 last:pb-0">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-base font-medium text-gray-900">{skill.name}</h3>
                  <Badge 
                    variant={proficiencyColor[skill.proficiency] as any}
                    size="sm"
                  >
                    {skill.proficiency.charAt(0).toUpperCase() + skill.proficiency.slice(1)}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">{skill.description}</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-4 text-center">
            <p className="text-gray-500">{emptyMessage}</p>
          </div>
        )}
      </CardBody>
    </Card>
  );
};

export default SkillList;