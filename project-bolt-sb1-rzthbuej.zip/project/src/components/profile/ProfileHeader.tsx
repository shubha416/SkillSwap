import React from 'react';
import { MessageSquare, Calendar, MapPin, Star, Award, Shield } from 'lucide-react';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import { User } from '../../types';

interface ProfileHeaderProps {
  user: User;
  isCurrentUser: boolean;
}

const ProfileHeader: React.FC<ProfileHeaderProps> = ({ user, isCurrentUser }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="h-32 bg-gradient-to-r from-primary-500 to-secondary-500"></div>
      <div className="px-6 pb-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-end mt-[-48px] mb-6">
          <div className="h-24 w-24 rounded-full border-4 border-white bg-white overflow-hidden">
            {user.avatar ? (
              <img 
                src={user.avatar} 
                alt={user.name}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="h-full w-full bg-primary-100 flex items-center justify-center">
                <span className="text-2xl font-bold text-primary-500">
                  {user.name.charAt(0).toUpperCase()}
                </span>
              </div>
            )}
          </div>
          
          <div className="flex-1 mt-4 sm:mt-0 sm:ml-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 flex items-center">
                  {user.name}
                  {user.isVerified && (
                    <span 
                      className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800"
                      title="Verified User"
                    >
                      <Shield className="mr-1 h-3 w-3" />
                      Verified
                    </span>
                  )}
                </h1>
                <div className="flex items-center mt-1 text-gray-600">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span className="text-sm">{user.location}</span>
                </div>
              </div>
              
              {!isCurrentUser && (
                <div className="mt-4 sm:mt-0 flex space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    leftIcon={<MessageSquare className="h-4 w-4" />}
                  >
                    Message
                  </Button>
                  <Button 
                    variant="primary" 
                    size="sm" 
                    leftIcon={<Calendar className="h-4 w-4" />}
                  >
                    Schedule
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center">
            <Star className="h-5 w-5 text-accent-500 mr-1" />
            <span className="font-medium text-gray-900">{user.rating.toFixed(1)}</span>
            <span className="text-gray-600 ml-1">({user.reviewCount} reviews)</span>
          </div>
          
          <div className="flex items-center">
            <Award className="h-5 w-5 text-primary-500 mr-1" />
            <span className="text-gray-900">{user.skills.length} Skills</span>
          </div>
          
          <div className="flex items-center">
            <Calendar className="h-5 w-5 text-secondary-500 mr-1" />
            <span className="text-gray-900">Member since 2024</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;