import React from 'react';
import { Star } from 'lucide-react';
import Avatar from '../ui/Avatar';
import { Review } from '../../types';
import { Card, CardHeader, CardBody } from '../ui/Card';
import { format } from 'date-fns';

interface ReviewListProps {
  reviews: Review[];
  reviewCount: number;
  averageRating: number;
}

const ReviewList: React.FC<ReviewListProps> = ({ 
  reviews, 
  reviewCount, 
  averageRating 
}) => {
  return (
    <Card>
      <CardHeader className="flex flex-col sm:flex-row justify-between">
        <h2 className="text-lg font-semibold text-gray-900">Reviews</h2>
        <div className="flex items-center mt-2 sm:mt-0">
          <div className="flex">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star 
                key={star}
                className={`h-5 w-5 ${
                  star <= Math.round(averageRating) 
                    ? 'text-accent-500 fill-accent-500' 
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="ml-2 text-sm text-gray-600">
            {averageRating.toFixed(1)} ({reviewCount} reviews)
          </span>
        </div>
      </CardHeader>
      
      <CardBody>
        {reviews.length > 0 ? (
          <div className="space-y-6">
            {reviews.map((review) => (
              <div key={review.id} className="border-b border-gray-200 last:border-b-0 pb-4 last:pb-0">
                <div className="flex items-start">
                  <Avatar 
                    src="https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=600" 
                    name="Jane Smith" 
                    size="md" 
                  />
                  
                  <div className="ml-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-medium text-gray-900">Jane Smith</h3>
                      <span className="text-xs text-gray-500">
                        {format(new Date(review.timestamp), 'MMMM d, yyyy')}
                      </span>
                    </div>
                    
                    <div className="flex mt-1 mb-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star 
                          key={star}
                          className={`h-4 w-4 ${
                            star <= review.rating 
                              ? 'text-accent-500 fill-accent-500' 
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    
                    <p className="text-sm text-gray-600">{review.content}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-4 text-center">
            <p className="text-gray-500">No reviews yet.</p>
          </div>
        )}
      </CardBody>
    </Card>
  );
};

export default ReviewList;