import React, { useState } from 'react';
import { 
  format, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  isToday, 
  isSameDay, 
  addWeeks, 
  subWeeks,
  addHours,
  parseISO
} from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import Button from '../ui/Button';
import { ScheduledSession } from '../../types';

interface CalendarProps {
  sessions: ScheduledSession[];
  onSelectSession: (session: ScheduledSession) => void;
}

const Calendar: React.FC<CalendarProps> = ({ sessions, onSelectSession }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const start = startOfWeek(currentDate, { weekStartsOn: 1 });
  const end = endOfWeek(currentDate, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start, end });

  const goToPreviousWeek = () => {
    setCurrentDate(subWeeks(currentDate, 1));
  };

  const goToNextWeek = () => {
    setCurrentDate(addWeeks(currentDate, 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  // Generate hours from 8 AM to 8 PM
  const hours = Array.from({ length: 13 }, (_, i) => i + 8);

  // Get sessions for a specific day and hour
  const getSessionsForTimeSlot = (day: Date, hour: number) => {
    return sessions.filter(session => {
      const sessionDate = parseISO(session.start);
      return (
        isSameDay(sessionDate, day) && 
        sessionDate.getHours() === hour
      );
    });
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="p-4 flex items-center justify-between border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">
          {format(start, 'MMMM d')} - {format(end, 'MMMM d, yyyy')}
        </h2>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={goToToday}
          >
            Today
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={goToPreviousWeek}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={goToNextWeek}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div className="flex">
        {/* Time column */}
        <div className="w-16 border-r border-gray-200">
          <div className="h-12 border-b border-gray-200"></div>
          {hours.map(hour => (
            <div key={hour} className="h-20 flex items-center justify-center border-b border-gray-200">
              <span className="text-xs font-medium text-gray-500">
                {hour % 12 === 0 ? 12 : hour % 12} {hour >= 12 ? 'PM' : 'AM'}
              </span>
            </div>
          ))}
        </div>
        
        {/* Days columns */}
        <div className="flex-1 grid grid-cols-7">
          {days.map(day => (
            <div key={day.toString()} className="border-r last:border-r-0 border-gray-200">
              {/* Day header */}
              <div 
                className={`h-12 flex flex-col items-center justify-center border-b border-gray-200 ${
                  isToday(day) ? 'bg-primary-50' : ''
                }`}
              >
                <span className="text-xs font-medium text-gray-500">
                  {format(day, 'EEE')}
                </span>
                <span 
                  className={`text-sm font-semibold mt-1 ${
                    isToday(day) 
                      ? 'bg-primary-500 text-white rounded-full w-6 h-6 flex items-center justify-center' 
                      : 'text-gray-900'
                  }`}
                >
                  {format(day, 'd')}
                </span>
              </div>
              
              {/* Time slots */}
              {hours.map(hour => {
                const sessionsAtTimeSlot = getSessionsForTimeSlot(day, hour);
                
                return (
                  <div 
                    key={hour} 
                    className="h-20 border-b border-gray-200 p-1"
                  >
                    {sessionsAtTimeSlot.map(session => (
                      <div 
                        key={session.id}
                        onClick={() => onSelectSession(session)}
                        className={`
                          cursor-pointer p-1 rounded text-xs h-full
                          ${session.status === 'completed' 
                            ? 'bg-gray-100 text-gray-600' 
                            : session.status === 'cancelled' 
                              ? 'bg-red-100 text-red-700 line-through' 
                              : 'bg-primary-100 text-primary-700'}
                          hover:bg-opacity-80 transition
                        `}
                      >
                        <div className="font-medium truncate">{session.title}</div>
                        <div className="truncate">
                          {format(parseISO(session.start), 'h:mm a')} - {format(parseISO(session.end), 'h:mm a')}
                        </div>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Calendar;