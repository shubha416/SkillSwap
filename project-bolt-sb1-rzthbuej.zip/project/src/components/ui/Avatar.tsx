import React from 'react';

interface AvatarProps {
  src?: string;
  alt?: string;
  name?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  status?: 'online' | 'offline' | 'away' | 'busy' | 'none';
}

const Avatar: React.FC<AvatarProps> = ({
  src,
  alt,
  name,
  size = 'md',
  className = '',
  status = 'none',
}) => {
  const sizeClasses = {
    xs: 'h-6 w-6 text-xs',
    sm: 'h-8 w-8 text-sm',
    md: 'h-10 w-10 text-base',
    lg: 'h-12 w-12 text-lg',
    xl: 'h-16 w-16 text-xl',
  };
  
  const statusClasses = {
    online: 'bg-success-500',
    offline: 'bg-gray-400',
    away: 'bg-accent-500',
    busy: 'bg-error-500',
    none: 'hidden',
  };
  
  const statusSizeClasses = {
    xs: 'h-1.5 w-1.5',
    sm: 'h-2 w-2',
    md: 'h-2.5 w-2.5',
    lg: 'h-3 w-3',
    xl: 'h-3.5 w-3.5',
  };
  
  const getInitials = (name: string) => {
    if (!name) return '';
    const names = name.split(' ');
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  };
  
  return (
    <div className={`relative inline-block ${className}`}>
      <div 
        className={`
          ${sizeClasses[size]} 
          rounded-full overflow-hidden flex items-center justify-center
          ${!src ? 'bg-primary-500 text-white' : ''}
        `}
      >
        {src ? (
          <img 
            src={src} 
            alt={alt || name || 'Avatar'} 
            className="h-full w-full object-cover"
          />
        ) : (
          <span className="font-medium">{name ? getInitials(name) : '?'}</span>
        )}
      </div>
      
      {status !== 'none' && (
        <span 
          className={`
            absolute bottom-0 right-0 transform translate-y-1/4 
            ${statusClasses[status]} ${statusSizeClasses[size]}
            rounded-full ring-2 ring-white
          `}
        ></span>
      )}
    </div>
  );
};

export default Avatar;